// TODO: modes/boundary-shapes.glsl
