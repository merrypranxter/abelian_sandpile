// TODO: modes/single-source.glsl
