// abelian_sandpile — fbo-pingpong.js
// Read A → Write B → Swap. The feedback engine.

export class FBOPingPong {
  constructor(gl, w, h) {
    this.gl = gl;
    this.w = w; this.h = h;
    // TODO: create FBO pair
  }
  swap() { [this.read, this.write] = [this.write, this.read]; }
}
