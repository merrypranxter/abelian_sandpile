# abelian_sandpile

A creative coding project exploring the **Abelian sandpile model** (Bak-Tang-Wiesenfeld chip-firing). Drop grains on a grid; any cell with 4+ topples one to each neighbor. The final state is a fractal mandala, and it doesn't matter in what order the topplings happen — that's what "Abelian" means.

**Distinct from `cellular_automata`:** specific chip-firing topple rule, not life-like rules. **Distinct from `dla_clustering`:** aggregation vs. redistribution.

## What Is the Abelian Sandpile?

A cellular automaton on a 2D grid where each cell holds a number of grains. When a cell reaches 4 or more, it "topples" — sending one grain to each of its four neighbors. The process continues until every cell has fewer than 4 grains. The remarkable fact: the final stable configuration is independent of the order of topplings. Self-organized criticality emerges naturally.

## Project Structure

```
src/
  js/
    main.js           — WebGL setup, render loop, parameter UI
    fbo-pingpong.js   — grain-count state texture ping-pong
    color-maps.js     — 256px ramps
  shaders/
    modes/            — swappable initial-condition engines
      single-source.glsl — dump N grains on one cell
      rain.glsl       — random drops, watch avalanches
      identity.glsl   — the sandpile group identity element
      boundary-shapes.glsl — non-square domains
    topple.frag       — the chip-firing rule (ping-pong)
    color.frag        — grain count → palette
    post-process.frag — bloom
```

## Current Engines

- [ ] _single_source — dump 1,048,576 grains on one cell, stabilize → classic fractal
- [ ] _rain — continuous random drops, power-law avalanches (SOC)
- [ ] _identity — render the sandpile group identity element
- [ ] _boundary_shapes — non-square domains → different fractal edges

## Aesthetic Regimes

- [ ] million_grain_mandala — 1,048,576 grains, classic 4-tone, blooming over frames
- [ ] avalanche_rain — continuous drops, active-toppling cells glow neon
- [ ] identity_glyph — the uncanny sandpile identity element
- [ ] psychedelic_recount — grain counts → maximalist neon ramp

## Parameters

- `total_grains` — e.g. 1,048,576
- `source` — single | rain | custom
- `domain_shape` — square | circle | hex | custom
- `palette_mode` — classic_4tone | neon_ramp
- `topple_passes_per_frame` — crank this for big piles

## Ecosystem Hooks

GPGPU ping-pong kit. Cousins `cellular_automata`, `dla_clustering` (flag distinct). Pairs with `apollonian_gasket`, `fractals`.

---

*The order of toppling does not matter. The fractal does not care.*
